% 107108019
% EXERCISE 1 - DC TRANSIENT ANALYSIS

% get inputs

clc;
fprintf('Roll Number: 107108019\n\n');
fprintf('EXERCISE 1 - DC TRANSIENT ANALYSIS \n\n');

V = input('Enter the DC-source voltage (volt): ');
R = input('Enter the Resistance (ohm): ');
L = input('Enter the Inductance (henry): ');
C = input('Enter the Capacitance (farad): ');
T = input('Enter time of simulation (seconds): ');

if T == 0
    T = 100;
end

% system response

delta = R*R - 4*L/C;

% constants for underdamped case
x = -R/(2*L);
y = sqrt(-delta)/(2*L);

% constants for overdamped case
a = (-R + sqrt(delta))/(2*L);
b = (-R - sqrt(delta))/(2*L);
k = V / sqrt(delta);

if delta < 0
    fprintf('\nThe system is UNDERDAMPED\n');
    
    t = 0:0.0001:T;
    
    i = V/(y*L) * exp(x*t) .* sin(y*t);
    
    figure(1);
    plot(t,i,'r');
    xlabel('Time (seconds)');
    ylabel('Current (ampere)');
    title('Transient Current Response for an RLC Series Circuit on applying DC Step Voltage :::: UNDERDAMPED');
    legend('current');
    
    figure(2);
    plot(t,i*R,'r');
    xlabel('Time (seconds)');
    ylabel('Voltage across Resistance (volt)');
    title('Transient Voltage Response across Resistance for an RLC Series Circuit on applying DC Step Voltage :::: UNDERDAMPED');
    legend('voltage');
    
elseif delta == 0
    fprintf('\nThe system is CRITICALLY DAMPED\n');
    
    t = 0:0.0001:T;
        
    i = V/L * t .* exp(a*t);
    
    figure(1);
    plot(t,i,'g');
    xlabel('Time (seconds)');
    ylabel('Current (ampere)');
    title('Transient Current Response for an RLC Series Circuit on applying DC Step Voltage :::: CRITICALLY DAMPED');
    legend('current');
    
    figure(2);
    plot(t,i*R,'g');
    xlabel('Time (seconds)');
    ylabel('Voltage across Resistance (volt)');
    title('Transient Voltage Response across Resistance for an RLC Series Circuit on applying DC Step Voltage :::: CRITICALLY DAMPED');
    legend('voltage');
    
else
    fprintf('\nThe system is OVERDAMPED\n');
    
    t = 0:0.0001:T;
    
    i = V/(L*(a-b)) * (exp(a*t) - exp(b*t));
    
    figure(1);
    plot(t,i,'b');
    xlabel('Time (seconds)');
    ylabel('Current (ampere)');
    title('Transient Current Response for an RLC Series Circuit on applying DC Step Voltage :::: OVERDAMPED');
    legend('current');
    
    figure(2);
    plot(t,i*R,'b');
    xlabel('Time (seconds)');
    ylabel('Voltage across Resistance (volt)');
    title('Transient Voltage Response across Resistance for an RLC Series Circuit on applying DC Step Voltage :::: OVERDAMPED');
    legend('voltage');
end

